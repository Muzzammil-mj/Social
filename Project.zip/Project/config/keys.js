module.exports = {
  MongoURI:
    "mongodb+srv://corizo:corizo123@social-media.bvr815h.mongodb.net/?retryWrites=true&w=majority",
};
